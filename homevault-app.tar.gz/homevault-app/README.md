# HomeVault - Expense Manager

A mobile expense manager built with Expo and React Native.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the app
npm start
```

Then press:
- `a` → open on Android emulator
- `i` → open on iOS simulator
- `w` → open in browser
- Scan the QR code with **Expo Go** app (iOS / Android)

## Features
- Multiple vaults with sub-vaults (Family, Business, etc.)
- Credit / debit transactions with live balance
- Search across all transactions
- Member management with roles
- Receipt image upload
- Login / Register (mock — no backend needed)
- All data stored locally on device (AsyncStorage)

## Demo Login
Any email/phone + any password works on the login screen.
On first use, 2 vaults with 30+ sample transactions are auto-loaded.

## Project Structure
```
app/
  (auth)/       ← Login & Register screens
  (tabs)/       ← Home, Search, Profile
  vault/        ← Vault detail & Create vault
  transaction/  ← Add transaction
  members/      ← Member management
components/     ← Shared UI components
constants/
  colors.ts     ← Design tokens
  mockData.ts   ← Mock API responses & seed data
context/
  AuthContext.tsx    ← Authentication state
  VaultContext.tsx   ← Vaults & transactions state
```

## Connecting a Real Backend
Replace `mockLoginResponse` / `mockRegisterResponse` in
`constants/mockData.ts` with real `fetch()` calls.
Everything else stays the same.
