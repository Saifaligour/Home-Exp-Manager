# HomeVault - Expense Manager

A mobile expense manager built with **Expo 55**, **React Native 0.84**, and **React 19**.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the app
npm start
```

Then press:
- `a` to open on Android emulator
- `i` to open on iOS simulator
- `w` to open in web browser
- Scan the QR code with the **Expo Go** app on your phone

## Tech Stack

| Package | Version |
|---|---|
| Expo SDK | 55.0.9 |
| React | 19.2.4 |
| React Native | 0.84.1 |
| Expo Router | 55.0.8 |
| React Native Reanimated | 4.3.0 |
| AsyncStorage | 3.0.2 |
| TanStack Query | 5.96.1 |

## Features
- Multiple vaults with sub-vaults (Family, Business, etc.)
- Credit / debit transactions with live balance
- Search across all transactions
- Member management with roles
- Receipt image upload
- Login / Register (mock — no backend needed)
- All data stored locally on device via AsyncStorage

## Demo Login
Any email/phone + any password works on the login screen.
On first use, 2 vaults with 30+ sample transactions are auto-loaded.

## Project Structure
```
app/
  (auth)/       ← Login & Register screens
  (tabs)/       ← Home, Search, Settings
  vault/        ← Vault detail & Create vault
  transaction/  ← Add transaction
  members/      ← Member management
components/     ← Shared UI components
constants/
  colors.ts     ← Design tokens
  mockData.ts   ← Mock API responses & seed data
context/
  AuthContext.tsx    ← Authentication state
  VaultContext.tsx   ← Vaults & transactions state
```

## Connecting a Real Backend
Replace `mockLoginResponse` / `mockRegisterResponse` in
`constants/mockData.ts` with real `fetch()` calls.
Everything else stays the same.
